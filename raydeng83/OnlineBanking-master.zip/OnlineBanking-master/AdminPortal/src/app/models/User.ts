export class User {
	username: string;
	firstName: string;
	lastName: string;
	email: string;
	phone: string;
	primary: string;
	savings: string;
}