// import {Injectable} from '@angular/core';
// import {Http, Headers} from '@angular/http';

// @Injectable()
// export class TransactionService {

//   constructor (private http:Http){}

//   getUsers() {
//     let url = "http://localhost:8080/api/user/all";
//     return this.http.get(url, { withCredentials: true });
//   }

 
//    getPrimaryTransactionList() {

//    }
// }