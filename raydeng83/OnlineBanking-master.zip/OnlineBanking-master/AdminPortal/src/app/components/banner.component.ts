import {Component} from '@angular/core';

@Component({
  selector: 'banner',
  templateUrl: './banner.component.html'
})
export class BannerComponent {
  
}