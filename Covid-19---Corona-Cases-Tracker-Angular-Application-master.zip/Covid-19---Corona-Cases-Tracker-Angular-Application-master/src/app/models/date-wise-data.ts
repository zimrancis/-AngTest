export interface DateWiseData{
    country ?:string , 
    cases ?: number , 
    date  ?: Date
}